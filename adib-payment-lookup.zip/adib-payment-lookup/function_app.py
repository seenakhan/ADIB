import azure.functions as func
import json
import csv
import io
import re
import logging
import os

from azure.core.exceptions import ResourceNotFoundError, HttpResponseError
from azure.identity import DefaultAzureCredential
from azure.storage.filedatalake import DataLakeServiceClient


app = func.FunctionApp()


# ---------------------------------------------------------
# Configuration (App Settings)
#   STORAGE_ACCOUNT_NAME = adibdatalakestorage
#   FILE_SYSTEM_NAME     = payment-data
#   PAYMENT_FILE_PATH    = current/PaygentX_ADIB_Payments.csv
# ---------------------------------------------------------
# .get() instead of os.environ[...]: a missing setting no longer crashes the
# whole app at start-up (which makes every URL return 404 / "no functions").

STORAGE_ACCOUNT_NAME = os.environ.get("STORAGE_ACCOUNT_NAME", "").strip()
FILE_SYSTEM_NAME = os.environ.get("FILE_SYSTEM_NAME", "").strip()
PAYMENT_FILE_PATH = os.environ.get("PAYMENT_FILE_PATH", "").strip().lstrip("/")


# ---------------------------------------------------------
# Authentication (managed identity in Azure, `az login` locally)
# ---------------------------------------------------------

_credential = DefaultAzureCredential()
_datalake_service = None


def get_datalake_service() -> DataLakeServiceClient:
    global _datalake_service
    if _datalake_service is None:
        _datalake_service = DataLakeServiceClient(
            account_url=f"https://{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net",
            credential=_credential,
        )
    return _datalake_service


# ---------------------------------------------------------
# Validate transaction reference
# ---------------------------------------------------------

# Letters and numbers only, 5-35 characters (35 = ISO 20022 max for references)
REFERENCE_PATTERN = re.compile(r"[A-Za-z0-9]{5,35}")


def is_valid_reference(reference: str) -> bool:
    return bool(reference) and REFERENCE_PATTERN.fullmatch(reference.strip()) is not None


# ---------------------------------------------------------
# CSV helpers
# ---------------------------------------------------------

def normalise_header(name: str) -> str:
    """'Transaction Reference', 'TransactionReference', 'transaction_reference'
    all become 'transactionreference', so the lookup works whichever
    header style the file uses."""
    return re.sub(r"[^a-z0-9]", "", (name or "").lower())


def first_value(row: dict, *columns: str):
    """Return the first non-empty value among the given (normalised) columns."""
    for column in columns:
        value = row.get(column)
        if value:
            return value
    return None


# ---------------------------------------------------------
# Read payment data from ADLS (cached, refreshed when the file changes)
# ---------------------------------------------------------

_cache = {"etag": None, "rows": {}}


def load_payments() -> dict:
    file_client = (
        get_datalake_service()
        .get_file_system_client(FILE_SYSTEM_NAME)
        .get_file_client(PAYMENT_FILE_PATH)
    )

    etag = file_client.get_file_properties().etag
    if etag == _cache["etag"]:
        return _cache["rows"]

    # utf-8-sig strips the BOM that Excel adds; otherwise the first
    # header becomes '﻿TransactionReference' and nothing matches.
    content = file_client.download_file().readall().decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(content))

    headers = [normalise_header(h) for h in (reader.fieldnames or [])]
    if "transactionreference" not in headers:
        raise ValueError(
            f"Payment file has no Transaction Reference column. Headers found: {reader.fieldnames}"
        )

    rows = {}
    for raw in reader:
        row = {normalise_header(k): (v or "").strip() for k, v in raw.items() if k}
        reference = row.get("transactionreference")
        if reference:
            rows[reference.upper()] = row

    _cache.update(etag=etag, rows=rows)
    logging.info("Payment file loaded: %d records.", len(rows))
    return rows


def get_payment_from_adls(reference: str) -> dict:
    row = load_payments().get(reference.strip().upper())

    if row is None:
        return {"found": False, "transactionReference": reference}

    # IMPORTANT: only return fields approved for the agent.
    return {
        "found": True,
        "transactionReference": row.get("transactionreference"),
        "status": first_value(row, "status"),
        "rejectionReason": first_value(row, "rejectionreason"),
        "requiredInformation": first_value(row, "requiredinformation"),
        # Falls back to 'Created Date Time' when the file has no LastUpdated column
        "lastUpdated": first_value(row, "lastupdated", "createddatetime"),
    }


# ---------------------------------------------------------
# HTTP API
# ---------------------------------------------------------

def json_response(body: dict, status_code: int) -> func.HttpResponse:
    return func.HttpResponse(json.dumps(body), status_code=status_code, mimetype="application/json")


def lookup_error() -> func.HttpResponse:
    return json_response(
        {
            "found": False,
            "error": "PaymentLookupError",
            "message": "Payment information could not be retrieved.",
        },
        500,
    )


@app.route(
    route="payment-status/{transactionReference}",
    methods=["GET"],
    # FUNCTION level: callers must send ?code=<function key> or the
    # x-functions-key header. ANONYMOUS exposed payment data to anyone.
    auth_level=func.AuthLevel.FUNCTION,
)
def payment_status(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Payment status request received.")

    missing = [
        name
        for name, value in {
            "STORAGE_ACCOUNT_NAME": STORAGE_ACCOUNT_NAME,
            "FILE_SYSTEM_NAME": FILE_SYSTEM_NAME,
            "PAYMENT_FILE_PATH": PAYMENT_FILE_PATH,
        }.items()
        if not value
    ]
    if missing:
        logging.error("Missing app settings: %s", ", ".join(missing))
        return lookup_error()

    reference = req.route_params.get("transactionReference")

    if not is_valid_reference(reference):
        return json_response(
            {
                "found": False,
                "error": "InvalidTransactionReference",
                "message": "Transaction reference must be 5-35 letters and numbers only.",
            },
            400,
        )

    try:
        return json_response(get_payment_from_adls(reference), 200)

    except ResourceNotFoundError:
        logging.error(
            "Payment file not found: file system '%s', path '%s'. Check FILE_SYSTEM_NAME / PAYMENT_FILE_PATH (case-sensitive).",
            FILE_SYSTEM_NAME,
            PAYMENT_FILE_PATH,
        )
        return lookup_error()

    except HttpResponseError as ex:
        # error_code tells you exactly what storage rejected, e.g.
        # AuthorizationPermissionMismatch -> identity lacks 'Storage Blob Data Reader'
        # AuthorizationFailure            -> storage firewall / network blocking the function
        logging.error("Storage request failed: HTTP %s, error code %s", ex.status_code, ex.error_code)
        return lookup_error()

    except Exception:
        logging.exception("Error retrieving payment information.")
        return lookup_error()